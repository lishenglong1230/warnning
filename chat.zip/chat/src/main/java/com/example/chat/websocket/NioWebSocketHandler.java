package com.example.chat.websocket;


import com.example.chat.entity.Message;
import com.example.chat.mapper.NettyMapper;
import com.example.chat.service.MessageService;
import com.example.chat.util.JsonUtil;
import com.google.gson.Gson;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * Netty服务器的核心处理类
 */
@Component
public class NioWebSocketHandler extends SimpleChannelInboundHandler<TextWebSocketFrame> {

//    public static NioWebSocketHandler nioWebSocketHandler;

    private final Logger logger = Logger.getLogger(String.valueOf(NioWebSocketHandler.class));

    public static ConcurrentHashMap<String, Channel> channelMap = new ConcurrentHashMap<>();

    private MessageService messageService;

    public NioWebSocketHandler(MessageService messageService){

        this.messageService = messageService;
    }

//    @PostConstruct
//    public void init(){
//        nioWebSocketHandler = this;
//        nioWebSocketHandler.messageService = this.messageService;
//    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, TextWebSocketFrame webSocketFrame) throws Exception {

        handlerWebSocketFrame(ctx, webSocketFrame);

    }

    private void handlerWebSocketFrame(ChannelHandlerContext ctx, TextWebSocketFrame webSocketFrame) {
        Message message = new Gson().fromJson(webSocketFrame.text(), Message.class);

        String toCode = message.getToCode();

        Channel channel = channelMap.get(toCode);
        if (channel == null) {
            ctx.channel().writeAndFlush(new TextWebSocketFrame(new Gson().toJson(new Message("对方已下线", message.getTimestamp(), message.getFromCode(), message.getToCode()))));
        } else {
            channel.writeAndFlush(new TextWebSocketFrame(JsonUtil.getJson(message)));
        }

        messageService.AddMessage(message);

        logger.info(message.getContent());
    }


    @Override
    public void handlerAdded(ChannelHandlerContext ctx) throws Exception {
        channelMap.put(ctx.channel().id().asShortText(), ctx.channel());
        logger.info(ctx.channel().remoteAddress() + "上线！" + "--->" + ctx.channel().id().asShortText());
    }


    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        //断开连接
        logger.info(ctx.channel().remoteAddress() + "下线！");
    }

    private void sendMessageByChannel(Channel channel, Message message) {

        channel.writeAndFlush(new TextWebSocketFrame(new Gson().toJson(message)));

    }
}
