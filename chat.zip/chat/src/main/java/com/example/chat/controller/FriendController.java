package com.example.chat.controller;

import com.example.chat.entity.Friend;
import com.example.chat.entity.Message;
import com.example.chat.service.FriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class FriendController {

    @Autowired
    private FriendService friendService;

    @RequestMapping(value = "/addFriend", method = RequestMethod.GET)
    public String addFriend(@RequestParam String fromCode, @RequestParam String toCode) {
        int res = friendService.addFriend(fromCode, toCode);
        System.out.println(res);

        return "ok";
    }

    @RequestMapping(value = "/getAllFriend", method = RequestMethod.GET)
    public List<Friend> getAllFriend(@RequestParam String fromCode) {
        List<Friend> allFriend = friendService.getAllFriend(fromCode);

        return allFriend;
    }


}
